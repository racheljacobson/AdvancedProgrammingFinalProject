package com.sw409.studentlibrarydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentLibraryDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
